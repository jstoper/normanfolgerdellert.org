<?php 
	//Define the folder where your photos will be placed on you server.
	//Relative to the path you place the galery index.php
	$gallerypath="images"; 		//EX. images or ../gallery/images no trailing slash needed 
	$thumbpath="imagethumbs";	//EX.  images or ../gallery/images no trailing slash needed
	$transitionspeed="500";		//How fast you want the animations to render
	$fadespeed="300";			//How fast you want the photos to fade in and out
	$users[0]="marissa";	//Username for accessing image uploader 
	$passw[0]="xmas08";		//Password to access image uploader
?>
